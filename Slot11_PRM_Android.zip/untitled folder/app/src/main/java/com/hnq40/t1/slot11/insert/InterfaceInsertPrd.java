package com.hnq40.t1.slot11.insert;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface InterfaceInsertPrd {
    @FormUrlEncoded
    @POST("insert.php")
    Call<SvrResponsePrd> insertPrd(
            @Field("MaSP") String MaSP,
            @Field("TenSP") String TenSP,
            @Field("DonGia") String DonGia,
            @Field("SoLuong") String SoLuong
    );
}
