package com.hnq40.t1.slot5n;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.hnq40.t1.slot5.Slot5Product;

import java.util.ArrayList;
import java.util.List;

public class Slot5nProductDAO {
    private Slot5nHelper dbHelper;
    private SQLiteDatabase db;
    private Context context;
    public Slot5nProductDAO(Context context){
        this.context = context;//truyen context
        dbHelper = new Slot5nHelper(context);//goi ham tao csdl
        db = dbHelper.getWritableDatabase();//cho phep ghi du lieu vao datbase
    }
    //ham insert du lieu
    public int insertProduct(Slot5nProduct p){
        ContentValues values = new ContentValues();//tao doi tuong chua du lieu
        //truyen du lieu
        values.put("id",p.getId());
        values.put("name",p.getName());
        values.put("price",p.getPrice());
        //thuc hien insert
        if(db.insert("Product",null,values)<0){
            return  -1; //insert that bai
        }
        return 1;//insert thanh cong
    }
    //ham doc du lieu tu bang
    public List<Slot5nProduct> getAllData(){
        //tao list chua du lieu
        List<Slot5nProduct> list = new ArrayList<>();
        //Tao contro doc du lieu
        Cursor cursor=db.query("Product",null,null,null,null,null,null);
        //di chuyen con tro ve ban ghi dau tien
        cursor.moveToFirst();
        while (cursor.isAfterLast()==false){//neu khong phai ban ghi cuoi cung
            Slot5nProduct p = new Slot5nProduct();//tao doi tuong chua du lieu
            //dua du lieu doc duoc vao doi tuong
            p.setId(cursor.getString(0));
            p.setName(cursor.getString(1));
            p.setPrice(cursor.getDouble(2));
            list.add(p);//dua doi tuong vao list
            cursor.moveToNext();//di chuyen den ban ghi tiep theo
        }
        cursor.close();//dong con tro
        return list;
    }
    //sua
    public int updateProduct(Slot5nProduct p){
        ContentValues values = new ContentValues();//tao doi tuong chua du lieu
        //truyen du lieu
        values.put("id",p.getId());
        values.put("name",p.getName());
        values.put("price",p.getPrice());
        //thuc hien insert
        if(db.update("Product",values,"id=?",new String[]{p.getId()})<0){
            return  -1; //update that bai
        }
        return 1;//update thanh cong
    }
    //xoa
    public int deleteProduct(String id){
        if(db.delete("Product","id=?",new String[]{id})<0){
            return -1;//xoa khong thanh cong
        }
        return 1;//xoa thanh cong
    }
}
