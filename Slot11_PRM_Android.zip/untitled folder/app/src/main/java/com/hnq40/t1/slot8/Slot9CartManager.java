package com.hnq40.t1.slot8;

import java.util.ArrayList;
import java.util.List;

public class Slot9CartManager {
    private static Slot9CartManager instance;
    private List<Slot8Product> cartItems;
    public Slot9CartManager(){
        cartItems=new ArrayList<>();
    }
    //synchronize
    public static synchronized Slot9CartManager getInstance(){
        if(instance == null){
            instance=new Slot9CartManager();//neu gio hang null -> tao moi
        }
        return instance;
    }
    //add product to cart method
    public void addProductToCart(Slot8Product product){
        cartItems.add(product);
    }
    //lay ve gio hang
    public List<Slot8Product> getCartItems(){
        return cartItems;
    }
}
