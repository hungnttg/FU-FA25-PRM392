package com.hnq40.t1.slot5n;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.t1.R;

import java.util.List;

public class Slot5nAdapter extends BaseAdapter {
    private Context context;
    private List<Slot5nProduct> list;
    public Slot5nAdapter(Context context, List<Slot5nProduct> list) {
        this.context = context;
        this.list = list;
    }
    @Override
    public int getCount() {
        return list.size();
    }
    @Override
    public Object getItem(int position) {
        return list.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view + gan du lieu cho view

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. tao view
        Slot5nHolder holder;
        if(convertView == null){//chua co view thi tao view moi
            //tao blank view
            convertView= LayoutInflater.from(context)
                    .inflate(R.layout.slot4n_itemview,parent,false);
            //anh xa tung truong
            holder = new Slot5nHolder();
            holder.img=convertView.findViewById(R.id.slot4n_itemview_img);
            holder.tvName=convertView.findViewById(R.id.slot4n_itemview_tvTen);
            holder.tvPrice=convertView.findViewById(R.id.slot4n_itemview_tvTuoi);
            holder.btnSua = convertView.findViewById(R.id.slot4n_itemview_BtnEdit);
            holder.btnXoa = convertView.findViewById(R.id.slot4n_itemview_BtnDelete);
            holder.btnXoa.setOnClickListener(v->{
                //xoa trong csdl
                Slot5nProductDAO dao = new Slot5nProductDAO(context);
                dao.deleteProduct(list.get(position).getId());
                //xoa trong list
                list.remove(position);
                //cap nhat adapter
                notifyDataSetChanged();
            });
            holder.btnSua.setOnClickListener(v->{
                //lay du lieu tu doi tuong => dua vao giao dien
                ((Slot5nMainActivity)context).setDataToForm(list.get(position));
            });
            //tao template de lan sau su dung
            convertView.setTag(holder);
        }
        else  {//neu da co view thi su dung view cu
            holder = (Slot5nHolder) convertView.getTag();
        }
        //2. gan du lieu cho view
        Slot5nProduct p = list.get(position);
        if(p!=null){
            holder.img.setImageResource(R.drawable.android);
            holder.tvName.setText(p.getName());
            holder.tvPrice.setText(String.valueOf(p.getPrice()));
        }
        return convertView;
    }
    static class Slot5nHolder{
        ImageView img;
        TextView tvName, tvPrice;
        Button btnSua,btnXoa;
    }
}
