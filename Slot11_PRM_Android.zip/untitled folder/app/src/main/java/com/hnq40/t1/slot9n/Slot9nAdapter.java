package com.hnq40.t1.slot9n;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.t1.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Slot9nAdapter extends BaseAdapter {
    private Context mContext;
    private List<Slot9nProduct> mList;
    public Slot9nAdapter(Context context,List<Slot9nProduct> list){
        this.mContext=context;
        this.mList=list;
    }
    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Slot9nViewHolder holder;
        if(convertView==null){
            convertView= LayoutInflater.from(mContext)
                    .inflate(R.layout.slot4_1_item_view,parent,false);
            holder = new Slot9nViewHolder();
            holder.imageView = convertView.findViewById(R.id.slot4_1_itemview_img);
            holder.tvTen = convertView.findViewById(R.id.slot4_1_itemview_tvTen);
            holder.tvTuoi = convertView.findViewById(R.id.slot4_1_itemview_tvTuoi);
            convertView.setTag(holder);
        }
        else {
            holder = (Slot9nViewHolder)convertView.getTag();
        }
        Slot9nProduct product=mList.get(position);
        if(product!=null){
            //Lay du lieu anh tu mang
            Picasso.get().load(product.getSearchImage()).into(holder.imageView);
            holder.tvTen.setText(product.getAdditionalInfo());
            holder.tvTuoi.setText(product.getPrice());
        }
        //xu ly su kien o day:
        convertView.setOnClickListener(v->{
            //lay ve san pham vua click
            Slot9nProduct p = mList.get(position);
            //Su dung intent de chuyen du lieu
            Intent intent = new Intent(mContext, Slot10DetailActivity.class);
            //dua object vao Intent
            intent.putExtra("PRODUCT",product);
            mContext.startActivity(intent);
        });
        return convertView;
    }
    static class Slot9nViewHolder{
        ImageView imageView;
        TextView tvTen,tvTuoi;
    }
}
