package com.hnq40.t1.slot9n;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import java.util.List;

public class SLot10nCartActivity extends AppCompatActivity {
    private ListView cart_listview;
    private Slot10nCartAdapter cartAdapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot10n_cart);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        cart_listview = findViewById(R.id.slot10n_Cart_Listview);
        //khoi tao danh sach gio hang va adapter (lay instance)
        Sloy10nCartManager cartManager = Sloy10nCartManager.getInstance();
        List<Slot9nProduct> cartItems = cartManager.getCartItems();
        //khoi tao adaper
        cartAdapter = new Slot10nCartAdapter(this,cartItems);
        cart_listview.setAdapter(cartAdapter);
    }
}