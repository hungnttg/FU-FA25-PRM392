package com.hnq40.t1.slot4n;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.t1.R;

import java.util.List;

public class Slot4nAdapter extends BaseAdapter {
    private List<Slot4nSinhVien> list;
    private Context context;

    public Slot4nAdapter(List<Slot4nSinhVien> list, Context context) {
        this.list = list;
        this.context = context;
    }

    //tinh tong so item
    @Override
    public int getCount() {
        return list.size();
    }
    //tra ve 1 item
    @Override
    public Object getItem(int position) {
        return list.get(position);
    }
    //tra ve id cua item
    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao blank view
    //dien du lieu cho view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. Tao blank view
        Slot4nViewHolder holder;
        if(convertView == null){//chua ton tai view -> tao blank view moi
            //anh xa layout voi convertview
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.slot4n_itemview,parent,false);
            //anh xa tung truong du lieu
            holder = new Slot4nViewHolder();
            holder.slot4n_img = convertView.findViewById(R.id.slot4n_itemview_img);
            holder.slot4n_tvTen=convertView.findViewById(R.id.slot4n_itemview_tvTen);
            holder.slot4n_tvTuoi=convertView.findViewById(R.id.slot4n_itemview_tvTuoi);
            //tao template de lan sau su dung
            convertView.setTag(holder);
        }
        else {//neu da ton tai => su dung luon
            holder = (Slot4nViewHolder)convertView.getTag();//lay ve template da tao tu truoc
        }
        //2. Gan du lieu cho view
        Slot4nSinhVien s = list.get(position);
        holder.slot4n_img.setImageResource(s.getHinh());
        holder.slot4n_tvTen.setText(s.getTen());
        holder.slot4n_tvTuoi.setText(s.getTuoi());
        return convertView;
    }
    static class Slot4nViewHolder {
        ImageView slot4n_img;
        TextView slot4n_tvTen,slot4n_tvTuoi;
    }
}
