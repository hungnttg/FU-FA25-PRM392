package com.hnq40.t1.slot11.insert;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Slot11MainActivity extends AppCompatActivity {
    EditText txtMaSP,txtTenSP,txtDonGia,txtSoLuong;
    Button btnInsert, btnDelete,btnUpdate,btnSelect;
    ListView listView;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot11_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa
        txtMaSP=findViewById(R.id.slot11_txtMaSP);
        txtTenSP=findViewById(R.id.slot11_txtTenSP);
        txtDonGia=findViewById(R.id.slot11_txtDonGia);
        txtSoLuong=findViewById(R.id.slot11_txtSoLuong);
        //
        btnInsert=findViewById(R.id.slot11_btnInsert);
        //
        btnInsert.setOnClickListener(v->{
            insertData();
        });
    }

    private void insertData() {
        //1/ tao doi tuong chua du lieu
        Prd prd=new Prd();
        //2. dua du lieu nhap tren Android vao doi tuong
        prd.setMaSP(txtMaSP.getText().toString());
        prd.setTenSP(txtTenSP.getText().toString());
        prd.setDonGia(txtDonGia.getText().toString());
        prd.setSoLuong(txtSoLuong.getText().toString());
        //3. tao doi tuong Retrofit
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://172.20.10.4/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //4. goi ham trong interface
        //4.0. toa doi tuong
        InterfaceInsertPrd insertPrdObj = retrofit.create(InterfaceInsertPrd.class);
        //4.1 chuan bi ham
        Call<SvrResponsePrd> call = insertPrdObj.insertPrd(prd.getMaSP(),
                prd.getTenSP(),prd.getDonGia(),
                prd.getSoLuong());
        //4.2. thuc thi ham
        call.enqueue(new Callback<SvrResponsePrd>() {
            //neu thanh cong
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                SvrResponsePrd svrResponsePrd=response.body();//lay ket qua tra ve tu server
                //hien thi ket qua
                Toast.makeText(context,svrResponsePrd.getMessage(),Toast.LENGTH_SHORT).show();
            }
            //neu that bai
            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable t) {
                //hien thi loi
                Toast.makeText(context,t.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}