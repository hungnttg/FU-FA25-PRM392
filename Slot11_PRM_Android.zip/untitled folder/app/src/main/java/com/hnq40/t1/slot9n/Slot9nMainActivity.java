package com.hnq40.t1.slot9n;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Slot9nMainActivity extends AppCompatActivity {
    ListView listView;
    Slot9nAdapter adapter;
    Context context = this;
    List<Slot9nProduct> productList;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot9n_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listView = findViewById(R.id.slot9nListview);
        productList = new ArrayList<>();
        adapter = new Slot9nAdapter(context,productList);
        listView.setAdapter(adapter);
        //lay du lieu tu server
        new FetchProductsTask().execute();
        //ham execute se thuc hien 2 tac vu:
        //1. doc du lieu tu server thong qua hamf FechProduct
        //2. tra du lieu ve user
    }
    private  class  FetchProductsTask extends AsyncTask<Void,Void,String>{
        //doc du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            StringBuilder response=new StringBuilder();
            try {
                URL url = new URL("https://hungnttg.github.io/shopgiay.json");
                //ket noi voi http
                HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                connection.setRequestMethod("GET");
                //tao bo dem doc du lieu
                BufferedReader reader=
                        new BufferedReader(new InputStreamReader(connection.getInputStream()));
                //doc du lieu theo dong
                String line="";
                while ((line=reader.readLine())!=null){
                    response.append(line);// doc tung dong va dua vao phan reponse
                }
                reader.close();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (ProtocolException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return response.toString();
        }
        //tra du lieu ve client

        @Override
        protected void onPostExecute(String result) {
            if(result != null && !result.isEmpty()){
                try {
                    JSONObject json = new JSONObject(result);
                    JSONArray productsArray = json.getJSONArray("products");
                    for(int i=0;i<productsArray.length();i++){
                        JSONObject productObject = productsArray.getJSONObject(i);
                        String styleid=productObject.getString("styleid");
                        String brand = productObject.getString("brands_filter_facet");
                        String price = productObject.getString("price");
                        String additionInfo=productObject.getString("product_additional_info");
                        String searchImage = productObject.getString("search_image");
                        //rao poduct voi cacs thong tin tren
                        Slot9nProduct p=new Slot9nProduct(styleid,brand,price,additionInfo,searchImage);
                        //add vao list
                        productList.add(p);
                    }
                    adapter.notifyDataSetChanged();//cap nhat adapter
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}