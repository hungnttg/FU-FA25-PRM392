package com.hnq40.t1.slot8;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;
import com.squareup.picasso.Picasso;

public class Slot9DetailActivity extends AppCompatActivity {
    Button btnAddToCart;
    private Slot9CartManager cartManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot9_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //tao 1 the hien duy nhat cuar CartManager
        cartManager = Slot9CartManager.getInstance();

        //receive data from intent
        Intent intent = getIntent();
        Slot8Product product=intent.getParcelableExtra("PRODUCT");
        //reference component of layout
        ImageView imageViewProduct = findViewById(R.id.slot9DetailImg);
        TextView textViewStyleId = findViewById(R.id.slot9DetailStyleid);
        TextView textViewBrand = findViewById(R.id.slot9DetailBrands);
        TextView textViewPrice = findViewById(R.id.slot9DetailPrice);
        TextView textViewInfo = findViewById(R.id.slot9DetailInfo);
        btnAddToCart = findViewById(R.id.slot9DetailBtnAddToCart);
        btnAddToCart.setOnClickListener(v->{
            addToCartClicked();
        });
        //display detail of product
        if(product!=null){
            //get image
            Picasso.get().load(product.getSearch_image()).into(imageViewProduct);
            //get other fields
            textViewStyleId.setText("Style ID: "+product.getStyleid());
            textViewBrand.setText("Brands: "+product.getBrand());
            textViewPrice.setText("Price: "+product.getPrice());
            textViewInfo.setText("Info: "+product.getAdditionalInfo());
        }
    }

    private void addToCartClicked() {
        Intent intent = getIntent();
        Slot8Product product = intent.getParcelableExtra("PRODUCT");
        if(product != null){
            //them san pham vao gio hang
            cartManager.addProductToCart(product);
            //Mo Slot9CartActivity
            Intent cartIntent = new Intent(this,Slot9CartActivity.class);
            startActivity(cartIntent);
        }
    }
}