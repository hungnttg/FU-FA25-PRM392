package com.hnq40.t1.slot9n;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hnq40.t1.R;

import java.util.List;

public class Slot10nCartAdapter extends ArrayAdapter<Slot9nProduct> {
    private Context mContext;
    //khoi tao
    public Slot10nCartAdapter(@NonNull Context context, List<Slot9nProduct> products) {
        super(context, 0,products);
        mContext=context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem==null){
            listItem= LayoutInflater.from(mContext)
                    .inflate(R.layout.slot10n_cart_items,parent,false);
        }
        //lay san pham o vi tri hien tai
        Slot9nProduct currentProduct = getItem(position);
        //hien thi thong tin san pham trong danh sach gio hang
        TextView productName = listItem.findViewById(R.id.slot10nCartItem_TxtName);
        productName.setText(currentProduct.getAdditionalInfo());
        //hien thi so luong va gia san pham
        TextView productQuantity = listItem.findViewById(R.id.slot10nCartItem_TxtQuantity);
        productQuantity.setText("Quantity: "+1);
        return listItem;
    }
}
