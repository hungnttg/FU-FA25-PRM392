package com.hnq40.t1.slot9n;

import java.util.ArrayList;
import java.util.List;

public class Sloy10nCartManager {
    private static Sloy10nCartManager instance;
    private List<Slot9nProduct> cartItems;
    Sloy10nCartManager(){
        cartItems=new ArrayList<>();
    }
    //tao gio hang
    public static synchronized Sloy10nCartManager getInstance(){
        if(instance==null){
            instance=new Sloy10nCartManager();
        }
        return instance;
    }
    //them san pham vao gio hang
    public void addProductToCart(Slot9nProduct p){
        cartItems.add(p);
    }
    //lay danh sach san pham trong gio hang
    public List<Slot9nProduct> getCartItems(){
        return cartItems;
    }
}
