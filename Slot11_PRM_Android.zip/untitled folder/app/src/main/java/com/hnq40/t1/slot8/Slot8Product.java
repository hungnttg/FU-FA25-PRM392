package com.hnq40.t1.slot8;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Slot8Product implements Parcelable {
    private String styleid;
    private String brand;
    private String price;
    private String additionalInfo;
    private String search_image;

    public Slot8Product() {
    }

    public Slot8Product(String styleid, String brand, String price, String additionalInfo, String search_image) {
        this.styleid = styleid;
        this.brand = brand;
        this.price = price;
        this.additionalInfo = additionalInfo;
        this.search_image = search_image;
    }

    protected Slot8Product(Parcel in) {
        styleid = in.readString();
        brand = in.readString();
        price = in.readString();
        additionalInfo = in.readString();
        search_image = in.readString();
    }

    public static final Creator<Slot8Product> CREATOR = new Creator<Slot8Product>() {
        @Override
        public Slot8Product createFromParcel(Parcel in) {
            return new Slot8Product(in);
        }

        @Override
        public Slot8Product[] newArray(int size) {
            return new Slot8Product[size];
        }
    };

    public String getStyleid() {
        return styleid;
    }

    public void setStyleid(String styleid) {
        this.styleid = styleid;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getSearch_image() {
        return search_image;
    }

    public void setSearch_image(String search_image) {
        this.search_image = search_image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(styleid);
        dest.writeString(brand);
        dest.writeString(price);
        dest.writeString(additionalInfo);
        dest.writeString(search_image);
    }
}
