package com.hnq40.t1.slot8;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import java.util.List;

public class Slot9CartActivity extends AppCompatActivity {
    ListView listViewCart;
    private Slot9CartAdapter cartAdapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot9_cart);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listViewCart = findViewById(R.id.slot9Activity_Listview);
        //khoi tao danh sach gio hang va adapter
        //lay 1 the hien duy nhat cua CartManager
        Slot9CartManager cartManager = Slot9CartManager.getInstance();
        List<Slot8Product> cartItems = cartManager.getCartItems();
        //khoi tao adapter va thiet lap cho Listview
        cartAdapter = new Slot9CartAdapter(this,cartItems);
        listViewCart.setAdapter(cartAdapter);
    }
}