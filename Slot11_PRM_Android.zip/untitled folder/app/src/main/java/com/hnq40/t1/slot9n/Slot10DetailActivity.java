package com.hnq40.t1.slot9n;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;
import com.squareup.picasso.Picasso;

public class Slot10DetailActivity extends AppCompatActivity {
    Button btnAddToCart;
    TextView txtStyleID, txtBrand, txtPrice, txtInfo;
    private Sloy10nCartManager cartManager;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot10_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        cartManager = Sloy10nCartManager.getInstance();//khoi tao gio hang neu chua co
        btnAddToCart = findViewById(R.id.slot10n_Detail_BtnAddToCart);
        img = findViewById(R.id.Slot10n_detail_img);
        txtBrand=findViewById(R.id.slot10n_Detail_txtBrand);
        txtInfo=findViewById(R.id.slot10n_Detail_txtInfo);
        txtPrice=findViewById(R.id.slot10n_Detail_txtPrice);
        txtStyleID=findViewById(R.id.slot10n_Detail_txtStyleId);
        //nhan du lieu tu intent
        Intent intent = getIntent();
        Slot9nProduct p = intent.getParcelableExtra("PRODUCT");
        //dien du lieu
        if(p!=null){
            //hien thi anh
            Picasso.get().load(p.getSearchImage()).into(img);
            //hien thi cac thong tin khac
            txtStyleID.setText("Style ID: "+p.getStyleid());
            txtPrice.setText("Price: "+p.getPrice());
            txtBrand.setText("Brand: "+p.getBrand());
            txtInfo.setText("Info: "+p.getAdditionalInfo());
        }
        btnAddToCart.setOnClickListener(v->{
            addPrdToCart();
        });


    }

    private void addPrdToCart() {
        Intent intent = getIntent();
        Slot9nProduct product = intent.getParcelableExtra("PRODUCT");
        if(product!=null){
            //them sp vao gio hang
            cartManager.addProductToCart(product);
            Intent cartIntent = new Intent(this,SLot10nCartActivity.class);
            startActivity(cartIntent);
        }
    }
}