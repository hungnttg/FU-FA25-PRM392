package com.hnq40.t1.slot3;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

public class Slot3_2MainActivity extends AppCompatActivity {
    ListView listView; //khai bao listview
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot32_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa listview
        listView = findViewById(R.id.s3_2Listview);
        getDataToListview();
    }

    private void getDataToListview() {
        //1. create data source
        String[] arr = new String[]{
            "lap trinh java",
            "Computer science introduction",
            "mobile programing",
            "cross-platform with .net",
                "Javascript introduction"
        };
        //2. using adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(Slot3_2MainActivity.this,
                android.R.layout.simple_list_item_1,arr);
        //3. attach adapter to listview
        listView.setAdapter(adapter);
    }
}