<?php
$response=array();
header('Access-Control-Alow-Origin:*');
$s="localhost"; $u="root"; $p=""; $db="a0";//khai bao tt ket noi
$conn = new mysqli($s,$u,$p,$db);//tao ket noi den csdl
//neu truyen tham so: $_GET, $_POST
if(isset($_GET['MaSP'])){
    $MaSP=$_GET['MaSP']; 
    $sql="DELETE FROM SP WHERE MaSP='$MaSP'";
    if($conn->query($sql) === TRUE){//delete
        //echo "Xoa Thanh cong";
        $response['success']=1;
        $response['message']="Delete thanh cong";
        echo json_encode($response);
    }else {
        //echo "Xoa That bai";
        $response['success']=0;
        $response['message']=$conn->error;
        echo json_encode($response);
    }
}
$conn->close();
//cach goi:
//http://10.22.10.72/delete.php?MaSP=101
?>
