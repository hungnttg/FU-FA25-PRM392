<?php
header('Access-Control-Alow-Origin:*');
$s="localhost"; $u="root"; $p=""; $db="a0";//khai bao tt ket noi
$conn = new mysqli($s,$u,$p,$db);//tao ket noi den csdl
//neu truyen tham so: $_GET, $_POST
if(isset($_GET['MaSP']) && isset($_GET['TenSP']) && isset($_GET['DonGia']) && isset($_GET['SoLuong'])){
    $MaSP=$_GET['MaSP']; $TenSP=$_GET['TenSP']; $DonGia=$_GET['DonGia']; $SoLuong=$_GET['SoLuong'];
    $sql="UPDATE SP SET TenSP='$TenSP',DonGia='$DonGia',SoLuong='$SoLuong' WHERE MaSP='$MaSP'";
    if($conn->query($sql) === TRUE){//insert
        $response['success']=1;
        $response['message']="Update thanh cong";
        echo json_encode($response);
    }else {
        $response['success']=0;
        $response['message']=$conn->error;
        echo json_encode($response);
    }
}
$conn->close();
//cach goi:
//http://10.22.10.72/update.php?MaSP=100&TenSP=San pham update 101&DonGia=1234&SoLuong=1000
?>
