<?php
header('Access-Control-Alow-Origin:*');
$s="localhost"; $u="root"; $p=""; $db="a0";//khai bao tt ket noi
$conn = new mysqli($s,$u,$p,$db);//tao ket noi den csdl
//neu truyen tham so: $_POST, $_POST
if(isset($_POST['MaSP']) && isset($_POST['TenSP']) && isset($_POST['DonGia']) && isset($_POST['SoLuong'])){
    $MaSP=$_POST['MaSP']; $TenSP=$_POST['TenSP']; $DonGia=$_POST['DonGia']; $SoLuong=$_POST['SoLuong'];
    $sql="INSERT INTO SP VALUES ('$MaSP','$TenSP','$DonGia','$SoLuong')";
    if($conn->query($sql) === TRUE){//insert
        //echo "Thanh cong";
        $response['success']=1;
        $response['message']="Insert thanh cong";
        echo json_encode($response);
    }else {
        //echo "That bai";
        $response['success']=0;
        $response['message']=$conn->error;
        echo json_encode($response);
    }
}
$conn->close();
//cach goi:
//http://10.22.10.72/insert.php?MaSP=101&TenSP=San pham 101&DonGia=1234&SoLuong=1000
?>
