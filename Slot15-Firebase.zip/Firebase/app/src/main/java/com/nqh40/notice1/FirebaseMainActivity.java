package com.nqh40.notice1;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class FirebaseMainActivity extends AppCompatActivity {
    //b1 cai hinh db
    //b2 ket noi voi firebare va tao ten cho collection
    TextView tvKQ;
    Context context=this;
    FirebaseFirestore database;
    String id="";
    ToDo toDo=null;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_firebase_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tvKQ = findViewById(R.id.slot16_tvkq);
        database=FirebaseFirestore.getInstance();//khoi tao database
        //insertFirebase();
        //selectDataFromFirebase();
        updateFirebase();

    }
    public void insertFirebase(){
        //lay 1 ma ngau nhien bat ky
        id= UUID.randomUUID().toString();
        toDo = new ToDo(id,"title 2","content 2");
        HashMap<String,Object> mapTodo = toDo.convertHashMap();//convert sang du lieu co the insert
        database.collection("TODO").document(id)
                .set(mapTodo)//insert
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvKQ.setText("Them thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvKQ.setText(e.toString());
                    }
                });
    }
    public void updateFirebase(){
        //dua du lieu can update
        id="ad58a3ea-e971-4c7e-b4b4-adfddf4159c9";
        toDo = new ToDo(id,"sua title 1","suwa content 1");
        database.collection("TODO")
                .document(toDo.getId())//lay dong du lieu can update
                .update(toDo.convertHashMap())//update
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvKQ.setText("Update thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvKQ.setText(e.getMessage());
                    }
                });

    }
    public void deleteFirebase(){
        id="ad58a3ea-e971-4c7e-b4b4-adfddf4159c9";
        database.collection("TODO")
                .document(id)
                .delete()//thuc hien delete
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvKQ.setText("Xoa thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                    tvKQ.setText(e.getMessage());
                    }
                });
    }
    String strKQ="";
    public ArrayList<ToDo> selectDataFromFirebase(){
        ArrayList<ToDo> list = new ArrayList<>();
        database.collection("TODO")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()){//neu lay du lieu
                            strKQ="";
                            for(QueryDocumentSnapshot document: task.getResult()){
                                ToDo toDo1 = document.toObject(ToDo.class);
                                strKQ += "id: "+toDo1.getId()+"\n";
                                list.add(toDo1);
                            }
                            tvKQ.setText(strKQ);
                        }
                    }
                });
        return list;

    }

}