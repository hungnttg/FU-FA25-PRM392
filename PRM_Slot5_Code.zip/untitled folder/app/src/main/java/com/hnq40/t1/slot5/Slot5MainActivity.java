package com.hnq40.t1.slot5;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot5MainActivity extends AppCompatActivity {
    EditText txt1,txt2,txt3;
    Button btn1,btn2;
    ListView listView;
    Slot5Adapter adapter;
    List<Slot5Product> list = new ArrayList<>();
    Slot5ProductDAO dao;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot5_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txt1 = findViewById(R.id.slot51_txt1);
        txt2 = findViewById(R.id.slot51_txt2);
        txt3 = findViewById(R.id.slot51_txt3);
        btn1 = findViewById(R.id.slot51_Btn1);
        btn2 = findViewById(R.id.slot51_Btn2);
        listView = findViewById(R.id.slot51Listview);
        //-----
        dao = new Slot5ProductDAO(this);//tao csdl va bang du lieu
        list = dao.getAll();
        adapter = new Slot5Adapter(list,this);
        listView.setAdapter(adapter);
        //----
        btn1.setOnClickListener(v->{
            //lay du lieu nguoi dung nhap
            String id = txt1.getText().toString();
            String name = txt2.getText().toString();
            double price = Double.parseDouble(txt3.getText().toString());
            Slot5Product p = new Slot5Product(id,name,price);
            int i = dao.insertProduct(p);
            if(i<0){
                Toast.makeText(getApplicationContext(), "Insert that bai", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(getApplicationContext(), "Insert thanh cong", Toast.LENGTH_SHORT).show();
            }
        });
        btn2.setOnClickListener(v->{
            list = dao.getAll();
            adapter = new Slot5Adapter(list,this);
            listView.setAdapter(adapter);
        });


    }
}