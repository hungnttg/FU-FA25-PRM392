package com.hnq40.t1.slot3;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

public class Slot3_1MainActivity extends AppCompatActivity {
    //declare variable
    EditText txt1,txt2;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot31_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //refer widget to id in XML layout
        txt1 = findViewById(R.id.s3_1Txt1);
        txt2 = findViewById(R.id.s3_1Txt2);
        btn1  =findViewById(R.id.s3_1Btn1);
        btn1.setOnClickListener(v->{
            login();
        });
    }
    //define login function
    private void login(){
        if(txt1.getText().toString().equals("admin")
        && txt2.getText().toString().equals("123456")){
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
        }
        else  {
            Toast.makeText(this, "User or pass wrong", Toast.LENGTH_SHORT).show();
        }
    }
}