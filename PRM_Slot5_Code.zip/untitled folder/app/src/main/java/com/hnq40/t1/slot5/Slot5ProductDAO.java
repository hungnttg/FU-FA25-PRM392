package com.hnq40.t1.slot5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Slot5ProductDAO {
    private Slot5SQLiteHelper dbHelper;
    private SQLiteDatabase db;
    private Context context;
    public Slot5ProductDAO(Context context){
        this.context = context;//truyen context
        dbHelper = new Slot5SQLiteHelper(context);//tao database
        db=dbHelper.getWritableDatabase();//cho phep ghi du lieu
    }
    //ham insert
    public int insertProduct(Slot5Product p){
        ContentValues values = new ContentValues();//data for insert
        //put data
        values.put("id",p.getId());
        values.put("name",p.getName());
        values.put("price",p.getPrice());
        //thuc hien insert
        if(db.insert("Product",null,values)<0){
            return -1;//that bai
        }
        return 1;//thanh cong
    }
    //ham doc du lieu
    public List<Slot5Product> getAll(){
        List<Slot5Product> list = new ArrayList<>();
        //cursor read data
        Cursor c=db.query("Product",null,null,null,
                null,null,null);
        c.moveToFirst();//di chuyen con tro den ban ghi dau tien
        while (c.isAfterLast()==false){//neu khong phai ban ghi cuoi cung thi doc
            Slot5Product product = new Slot5Product();//tao doi tuong chua du lieu
            //dua du lieu vao doi tuong
            product.setId(c.getString(0));
            product.setName(c.getString(1));
            product.setPrice(c.getDouble(2));
            list.add(product);//dua vao list
            c.moveToNext();//chuyen ban ghi tiep theo
        }
        c.close();//dong con tro
        return list;
    }
}
