package com.hnq40.t1.slot4n;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot4nMainActivity extends AppCompatActivity {
    ListView listView;
    private Slot4nAdapter adapter;
    private List<Slot4nSinhVien> list = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot4n_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listView = findViewById(R.id.slot4nListview);
        //tao nguon du lieu
        list.add(new Slot4nSinhVien("Nguyen Van A","18",R.drawable.hp));
        list.add(new Slot4nSinhVien("Tran Van B","19",R.drawable.dell));
        list.add(new Slot4nSinhVien("Vu Van C","17",R.drawable.chrome));
        list.add(new Slot4nSinhVien("Nguyen Thi D","20",R.drawable.firefox));
        list.add(new Slot4nSinhVien("Nguyen Van Apple","18",R.drawable.apple));
        list.add(new Slot4nSinhVien("Tran Thi Facebook","20",R.drawable.facebook));
        //tao adapter
        adapter=new Slot4nAdapter(list,this);
        //gan adapter voi listview
        listView.setAdapter(adapter);
    }
}