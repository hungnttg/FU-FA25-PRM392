package com.hnq40.t1.slot5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.t1.R;

import java.util.List;

public class Slot5Adapter extends BaseAdapter {
    private List<Slot5Product> mList;
    private Context mContext;

    public Slot5Adapter(List<Slot5Product> mList, Context mContext) {
        this.mList = mList;
        this.mContext = mContext;
    }
    @Override
    public int getCount() {
        return mList.size();
    }
    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view + gan du lieu cho view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. tao view
        Slot5ViewHolder holder;
        if(convertView==null){//neu chua co view => tao view moi
            //create a blank view
            convertView = LayoutInflater.from(mContext)
                    .inflate(R.layout.slot4n_itemview,parent,false);
            //anh xa tung truong
            holder = new Slot5ViewHolder();
            holder.img = convertView.findViewById(R.id.slot4n_itemview_img);
            holder.tvName = convertView.findViewById(R.id.slot4n_itemview_tvTen);
            holder.tvPrice=convertView.findViewById(R.id.slot4n_itemview_tvTuoi);
            convertView.setTag(holder);//tao template de lan sau su dung
        }
        else {//neu da co view thi su dung view cu
            holder = (Slot5ViewHolder) convertView.getTag();
        }
        //2. gan du lieu cho view
        Slot5Product product = mList.get(position);
        if(product!=null){
            holder.img.setImageResource(R.drawable.android);
            holder.tvName.setText(product.getName());
            holder.tvPrice.setText(String.valueOf(product.getPrice()));
        }
        return convertView;
    }
    static class Slot5ViewHolder{
        ImageView img;
        TextView tvName,tvPrice;
    }
}
