package com.hnq40.t1.slot4;

import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot4_1MainActivity extends AppCompatActivity {
    private ListView listView;
    private  Slot4_1Adapter adapter;
    private List<Slot4Student> list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot41_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listView = findViewById(R.id.slot4_1Listview);
        list.add(new Slot4Student("Nguyen Van A","18",R.drawable.android));
        list.add(new Slot4Student("Tran Van B","19",R.drawable.apple));
        list.add(new Slot4Student("Vu Thi C","17",R.drawable.blogger));
        list.add(new Slot4Student("Hoang Van D","20",R.drawable.firefox));
        list.add(new Slot4Student("Lo Van E","22",R.drawable.dell));
        list.add(new Slot4Student("Nguyen Van X","18",R.drawable.chrome));
        list.add(new Slot4Student("Nguyen Thi y","19",R.drawable.hp));
        adapter=new Slot4_1Adapter(this,list);//create adapter
        listView.setAdapter(adapter);//attach adapter to listview
    }
}