<!doctype html>
<?php
session_start();//bat dau phien lam viec
require_once('SP.php');//import thu vien
global $result;//khai bao bien toan cuc
//luu cac thong tin khi edit
$editMaSP="";
if(isset($_POST['btnEdit'])){//khi nguoi dung click button Edit
  $editMaSP=$_POST['editMaSP'];//luu lai ma ma nguoi dung muon sua
}
?>
<html lang="en">
  <head>
    <title>Quan tri san pham</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-3">Quan tri san pham</h1>
            <p class="lead">chi tiet....</p>
            <hr class="my-2">
            <div class="card-columns">
                <div class="card">
                    <img class="card-img-top" src="holder.js/100x180/" alt="">
                    <div class="card-body">
                        <h4 class="card-title">Them San Pham</h4>
                        <form action="" method="post">
                            <div class="form-group">
                              <label for="">MaSP</label>
                              <input type="text"
                                class="form-control" value="<?php echo $editMaSP; ?>" name="txtMaSP" id="txtMaSP" aria-describedby="helpId" placeholder="nhap ma">
                            </div>
                            <div class="form-group">
                              <label for="">TenSP</label>
                              <input type="text"
                                class="form-control" name="txtTenSP" id="txtTenSP" aria-describedby="helpId" placeholder="nhap ten">
                            </div>
                            <div class="form-group">
                              <label for="">DonGia</label>
                              <input type="text"
                                class="form-control" name="txtDonGia" id="txtDonGia" aria-describedby="helpId" placeholder="nhap don gia">
                            </div>
                            <div class="form-group">
                              <label for="">SoLuong</label>
                              <input type="text"
                                class="form-control" name="txtSoLuong" id="txtSoLuong" aria-describedby="helpId" placeholder="nhap so luong">
                            </div>
                            <button type="submit" class="btn btn-primary" name="btnThem">Them</button>
                            <button type="submit" class="btn btn-primary" name="btnHienThi">Hien thi</button>
                            <button type="submit" class="btn btn-primary" name="btnUpdate">Sua</button>
                        </form>
                    </div>
                </div>
                <div class="card">
                    <img class="card-img-top" src="holder.js/100x180/" alt="">
                    <div class="card-body">
                        <h4 class="card-title">Danh sach san pham</h4>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>MaSP</th>
                                    <th>TenSP</th>
                                    <th>DonGia</th>
                                    <th>SoLuong</th>
                                    <th>....</th>
                                    <th>....</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php 
                                if(isset($_POST['btnHienThi'])){//khi nguoi dung click button hien thi
                                  $result = displaySP();//doc du lieu tu db
                                  while($row = $result->fetch_assoc()){//doc tung dong
                                    echo '<tr>';
                                    echo '<td scope="row">'.$row['MaSP'].'</td>';
                                    echo '<td>'.$row['TenSP'].'</td>';
                                    echo '<td>'.$row['DonGia'].'</td>';
                                    echo '<td>'.$row['SoLuong'].'</td>';
                                    echo '<td>
                                            <form action="" method="post">
                                              <input type="hidden" name="editMaSP" value="'.$row['MaSP'].'" >
                                              <button type="submit" class="btn btn-primary" name="btnEdit">Edit</button>
                                            </form>
                                          </td>';
                                    echo '<td>
                                            <form action="" method="post">
                                              <input type="hidden" name="deleteMaSP" value="'.$row['MaSP'].'" >
                                              <button type="submit" class="btn btn-primary" name="btnDelete">Delete</button>
                                            </form>
                                          </td>';
                                    echo '</tr>';
                                  }
                                }
                              ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <?php
        if(isset($_POST['btnThem'])){//khi nguoi dung click button them
          $MaSP = $_POST['txtMaSP'];//lay du lieu tu nguoi dung nhap
          $TenSP = $_POST['txtTenSP'];//
          $DonGia = $_POST['txtDonGia'];
          $SoLuong=$_POST['txtSoLuong'];
          //goi ham them du lieu
          $i = addSP($MaSP,$TenSP,$DonGia,$SoLuong);
          if($i<0){
            echo "Them that bai";
          }
          else {
            echo "Them thanh cong";
          }
        }
        //----
        if(isset($_POST['btnUpdate'])){//neu nguoi dung clicj button update
          $MaSP = $_POST['txtMaSP'];//lay du lieu tu nguoi dung nhap
          $TenSP = $_POST['txtTenSP'];//
          $DonGia = $_POST['txtDonGia'];
          $SoLuong=$_POST['txtSoLuong'];
          //goi ham update san pham
          $i=updateSP($MaSP,$TenSP,$DonGia,$SoLuong);
          if($i<0){
            echo "Update that bai";
          }
          else {
            echo "Update thanh cong";
          }
        }
        //-----
        if(isset($_POST['btnEdit'])){//khi nguoi dung click button edit
          $MaSP = $_POST['editMaSP'];
          echo "Edit product with MaSP: $MaSP";

        }
        //---
        if(isset($_POST['btnDelete'])){//khi nguoi dung click button Delete
            $MaSP = $_POST['deleteMaSP'];
            $i=deleteSP($MaSP);//goi ham xoa san pham
            if($i<0){
            echo "Xoa that bai";
          }
          else {
            echo "Xoa thanh cong";
          }
        }
      ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>