package com.hnq40.t1.slot2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

public class Slot2_1MainActivity extends AppCompatActivity {
    //khai bao control
    EditText txt1,txt2;
    Button btn1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot21_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa cac control
        txt1 = findViewById(R.id.slot2_1Txt1);
        txt2=findViewById(R.id.slot2_1Txt2);
        btn1 = findViewById(R.id.slot2_1Btn1);
        //xu ly su kien click button
        btn1.setOnClickListener(v->{
            //lay du lieu nguoi dung nhap va chuyen sang so
            float so1 = Float.parseFloat(txt1.getText().toString());
            float so2 = Float.parseFloat(txt2.getText().toString());
//            //thuc hien tinh tong
//            float tong = so1 + so2;
//            //dua ket qua dang thong bao
//            //tv1.setText(String.valueOf(tong));
//            Toast.makeText(getApplicationContext(),String.valueOf(tong),
//                    Toast.LENGTH_SHORT).show();
//            Tao intent
            Intent intent = new Intent(Slot2_1MainActivity.this,
                    Slot2_2MainActivity.class);
            //Dua du lieu vao intent
            intent.putExtra("a",so1);
            intent.putExtra("b",so2);
            //bat dau truyen du lieu (khoi dong activity)
            startActivity(intent);
        });
    }
}