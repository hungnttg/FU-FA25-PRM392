package com.hnq40.t1.slot1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

public class Slot1MainActivity extends AppCompatActivity {
    //khai bao 3 control
    EditText txt1;
    TextView tv1;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot1_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Anh xa cac control
        txt1 = findViewById(R.id.slot1Txt1);
        tv1  =findViewById(R.id.slot1Tv1);
        btn1  =findViewById(R.id.slot1Btn1);
        //xu ly su kien
        btn1.setOnClickListener(v->{
            //lay du lieu do nguoi dung nhap tu txt1
            String a = txt1.getText().toString();
            //dien vao tv1
            tv1.setText(a);
        });
    }
}