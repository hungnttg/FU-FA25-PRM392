package com.hnq40.t1.slot11.insert;

public class ServerResponsePrd {
    //dinh nghia ket qua trả ve
    private Prd[] products;
    private String message;

    public Prd[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
