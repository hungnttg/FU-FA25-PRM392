package com.hnq40.t1.slot11.insert;

public class SvrResponsePrd {
    private String message;

    public SvrResponsePrd() {
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
