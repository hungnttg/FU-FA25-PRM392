package com.hnq40.t1.slot11.insert;

import android.content.Context;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Slot11MainActivity extends AppCompatActivity {
    EditText txtMaSP,txtTenSP,txtDonGia,txtSoLuong;
    Button btnInsert, btnDelete,btnUpdate,btnSelect;
    ListView listView;
    Context context=this;
    List<String> lsString=new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot11_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa
        txtMaSP=findViewById(R.id.slot11_txtMaSP);
        txtTenSP=findViewById(R.id.slot11_txtTenSP);
        txtDonGia=findViewById(R.id.slot11_txtDonGia);
        txtSoLuong=findViewById(R.id.slot11_txtSoLuong);
        listView=findViewById(R.id.slot11Listview);
        //
        btnInsert=findViewById(R.id.slot11_btnInsert);
        btnSelect=findViewById(R.id.slot11_btnSelect);
        btnDelete=findViewById(R.id.slot11_btnDelete);
        //
        btnInsert.setOnClickListener(v->{
            insertData();
        });
        selectData();
        arrayAdapter = new ArrayAdapter<>(context,
                android.R.layout.simple_list_item_1,lsString);
        listView.setAdapter(arrayAdapter);
        btnSelect.setOnClickListener(v->{

            selectData();


        });
        //
        btnDelete.setOnClickListener(v->{
            deleteData(txtMaSP.getText().toString());
        });
    }

    private void deleteData(String MaSP) {
        //1. Tao doi tuong Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://172.20.10.4/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. goi ham select trong interface
                //2.1 tao doi tuong
        InterfaceSelectPrd interfaceSelectPrd =
        retrofit.create(com.hnq40.t1.slot11.insert.InterfaceSelectPrd.class);
        //2.2 chuan bi ham
        Call<ServerResponsePrd> call = interfaceSelectPrd.deleteExe(MaSP);
        //2.3. thuc thi hamn
        call.enqueue(new Callback<ServerResponsePrd>() {
            @Override
            public void onResponse(Call<ServerResponsePrd> call, Response<ServerResponsePrd> response) {
                ServerResponsePrd svr = response.body();
                Toast.makeText(Slot11MainActivity.this, svr.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ServerResponsePrd> call, Throwable t) {
                Toast.makeText(Slot11MainActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    String strResult=""; //chuyen ket qua sang chuoi va hien thi len listview
    List<Prd> ls; //chua du lieu doc duoc

    private void selectData() {
        //ham doc du lieu bang retrofit
        lsString.clear();
        strResult="";
        //1. Tao doi tuong
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://172.20.10.4/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. goi ham select trong interface
        //2.1 tao doi tuong
        InterfaceSelectPrd interfaceSelectPrd =
                retrofit.create(InterfaceSelectPrd.class);
        //2.2 chuan bi ham
        Call<ServerResponsePrd> call = interfaceSelectPrd.getPrd();
        //2.3. thuc thi hamn
        call.enqueue(new Callback<ServerResponsePrd>() {
            //thanh cong
            @Override
            public void onResponse(Call<ServerResponsePrd> call, Response<ServerResponsePrd> response) {
                //tra ve 1 list ket qua
                ServerResponsePrd svr = response.body();//nhan ket qua tra ve tu API
                //chuyen ket qua tu chuoi sang list
                ls=new ArrayList<>(Arrays.asList(svr.getProducts()));
                //chuyen sang dang chuoi
                for(Prd p: ls){
                    strResult = "Ma: "+p.getMaSP()+"; Name: "+p.getTenSP()+"; Price: "+p.getDonGia();
                    lsString.add(strResult);
                }
                arrayAdapter.notifyDataSetChanged();
            }
            //that bai
            @Override
            public void onFailure(Call<ServerResponsePrd> call, Throwable t) {
                Toast.makeText(Slot11MainActivity.this, t.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void insertData() {
        //1/ tao doi tuong chua du lieu
        Prd prd=new Prd();
        //2. dua du lieu nhap tren Android vao doi tuong
        prd.setMaSP(txtMaSP.getText().toString());
        prd.setTenSP(txtTenSP.getText().toString());
        prd.setDonGia(txtDonGia.getText().toString());
        prd.setSoLuong(txtSoLuong.getText().toString());
        //3. tao doi tuong Retrofit
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://172.20.10.4/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //4. goi ham trong interface
        //4.0. toa doi tuong
        InterfaceInsertPrd insertPrdObj = retrofit.create(InterfaceInsertPrd.class);
        //4.1 chuan bi ham
        Call<SvrResponsePrd> call = insertPrdObj.insertPrd(prd.getMaSP(),
                prd.getTenSP(),prd.getDonGia(),
                prd.getSoLuong());
        //4.2. thuc thi ham
        call.enqueue(new Callback<SvrResponsePrd>() {
            //neu thanh cong
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                SvrResponsePrd svrResponsePrd=response.body();//lay ket qua tra ve tu server
                //hien thi ket qua
                Toast.makeText(context,svrResponsePrd.getMessage(),Toast.LENGTH_SHORT).show();
            }
            //neu that bai
            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable t) {
                //hien thi loi
                Toast.makeText(context,t.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}