package com.hnq40.t1.slot11.insert;

public class Prd {
    private String MaSP,TenSP,DonGia, SoLuong;

    public Prd() {
    }

    public Prd(String maSP, String tenSP, String donGia, String soLuong) {
        MaSP = maSP;
        TenSP = tenSP;
        DonGia = donGia;
        SoLuong = soLuong;
    }

    public String getMaSP() {
        return MaSP;
    }

    public void setMaSP(String maSP) {
        MaSP = maSP;
    }

    public String getTenSP() {
        return TenSP;
    }

    public void setTenSP(String tenSP) {
        TenSP = tenSP;
    }

    public String getDonGia() {
        return DonGia;
    }

    public void setDonGia(String donGia) {
        DonGia = donGia;
    }

    public String getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(String soLuong) {
        SoLuong = soLuong;
    }
}
