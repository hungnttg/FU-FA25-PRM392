package com.hnq40.t1.slot5n;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Slot5nHelper extends SQLiteOpenHelper {
    public Slot5nHelper(@Nullable Context context) {
        super(context, "SQLitePrd", null, 1);//ham tao Database
    }
    public static final String SQL_TAO_BANG="CREATE TABLE Product (id text PRIMARY KEY,name text,price real);";
    //tao bang du lieu
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_TAO_BANG);
    }
    //upgrade bang du lieu
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Product");
    }
}
