package com.hnq40.t1.slot2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

public class Slot2_2MainActivity extends AppCompatActivity {
    TextView tvKQ;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot22_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tvKQ = findViewById(R.id.slot2_2Tv2);//anh xa
        //nhan ket qua tu intent1 chuyen sang
        Intent intent1 = getIntent();
        //unboxing
        float so1 = intent1.getExtras().getFloat("a");
        float so2 = intent1.getExtras().getFloat("b");
        //tinh tong
        float tong = so1+so2;
        //hien thi ket qua
        tvKQ.setText(String.valueOf(tong));
    }
}