package com.hnq40.t1.slot8;

public class Slot8Product {
    private String styleid;
    private String brand;
    private String price;
    private String additionalInfo;
    private String search_image;

    public Slot8Product() {
    }

    public Slot8Product(String styleid, String brand, String price, String additionalInfo, String search_image) {
        this.styleid = styleid;
        this.brand = brand;
        this.price = price;
        this.additionalInfo = additionalInfo;
        this.search_image = search_image;
    }

    public String getStyleid() {
        return styleid;
    }

    public void setStyleid(String styleid) {
        this.styleid = styleid;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getSearch_image() {
        return search_image;
    }

    public void setSearch_image(String search_image) {
        this.search_image = search_image;
    }
}
