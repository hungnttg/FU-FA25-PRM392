package com.hnq40.t1.slot5n;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot5nMainActivity extends AppCompatActivity {
    EditText txt1,txt2,txt3;
    Button btn1,btn2,btn3,btn4;
    ListView listView;
    private Slot5nAdapter adapter;
    List<Slot5nProduct> list = new ArrayList<>();
    Context context=this;
    Slot5nProductDAO dao;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot5n_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txt1 = findViewById(R.id.slot5n_Txt1);
        txt2 = findViewById(R.id.slot5n_Txt2);
        txt3 = findViewById(R.id.slot5n_Txt3);
        btn1 = findViewById(R.id.slot5n_Btn1);
        btn2 = findViewById(R.id.slot5n_Btn2);
        btn3 = findViewById(R.id.slot5n_Btn3);
        btn4 = findViewById(R.id.slot5n_Btn4);
        listView = findViewById(R.id.slot5n_Listview);
        dao = new Slot5nProductDAO(context); //goi ham tao csdl va bang du lieu
        list = dao.getAllData();
        adapter = new Slot5nAdapter(this,list);
        listView.setAdapter(adapter);
        btn1.setOnClickListener(v->{
            //lay du lieu nguoi dung nhap
            String id = txt1.getText().toString();
            String name = txt2.getText().toString();
            double price = Double.parseDouble(txt3.getText().toString());
            //tao doi tuong chua du lieu nguoi dung nhap
            Slot5nProduct p = new Slot5nProduct(id,name,price);
            //thuc hien insert
            int i= dao.insertProduct(p);
            if(i<0){
                Toast.makeText(context, "Insert that bai", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(context, "Insert thanh cong", Toast.LENGTH_SHORT).show();
            }
            btn2.callOnClick();
        });
        btn2.setOnClickListener(v->{
            list = dao.getAllData();
            adapter = new Slot5nAdapter(this,list);
            listView.setAdapter(adapter);
        });
        btn3.setOnClickListener(v->{
            Slot5nProduct p = new Slot5nProduct();
            p.setId(txt1.getText().toString());
            p.setName(txt2.getText().toString());
            p.setPrice(Double.parseDouble(txt3.getText().toString()));
            int i = dao.updateProduct(p);
            if(i<0){
                Toast.makeText(context, "Update that bai", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(context, "Update thanh cong", Toast.LENGTH_SHORT).show();
            }
            btn2.callOnClick();
        });
        btn4.setOnClickListener(v->{
            int i = dao.deleteProduct(txt1.getText().toString().trim());
            if(i<0){
                Toast.makeText(context, "Delete that bai", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(context, "Delete thanh cong", Toast.LENGTH_SHORT).show();
            }
            btn2.callOnClick();
        });


    }
    public void setDataToForm(Slot5nProduct p){
        txt1.setText(p.getId());
        txt2.setText(p.getName());
        txt3.setText(String.valueOf(p.getPrice()));
    }
}