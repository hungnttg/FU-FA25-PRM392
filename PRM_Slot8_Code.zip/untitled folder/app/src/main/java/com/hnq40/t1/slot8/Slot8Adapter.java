package com.hnq40.t1.slot8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.t1.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Slot8Adapter extends BaseAdapter {
    private Context mContext;
    private List<Slot8Product> mList;

    public Slot8Adapter(Context mContext, List<Slot8Product> mList) {
        this.mContext = mContext;
        this.mList = mList;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Slot8ViewHolder holder;
        if(convertView == null){
            convertView = LayoutInflater.from(mContext)
                    .inflate(R.layout.slot4n_itemview,parent,false);
            holder = new Slot8ViewHolder();
            holder.imageView = convertView.findViewById(R.id.slot4n_itemview_img);
            holder.txtName=convertView.findViewById(R.id.slot4n_itemview_tvTen);
            holder.txtPrice = convertView.findViewById(R.id.slot4n_itemview_tvTuoi);
            convertView.setTag(holder);
        }
        else  {
            holder = (Slot8ViewHolder) convertView.getTag();
        }
        Slot8Product p = mList.get(position);
        if(p!=null){
            Picasso.get().load(p.getSearch_image()).into(holder.imageView);
            holder.txtName.setText(p.getAdditionalInfo());
            holder.txtPrice.setText(p.getPrice());
        }
        return convertView;
    }
    static class Slot8ViewHolder{
        ImageView imageView;
        TextView txtName,txtPrice;
    }
}
