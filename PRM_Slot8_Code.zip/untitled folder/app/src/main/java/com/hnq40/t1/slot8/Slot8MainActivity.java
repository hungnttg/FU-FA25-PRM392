package com.hnq40.t1.slot8;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Slot8MainActivity extends AppCompatActivity {
    ListView listView;
    Slot8Adapter adapter;
    List<Slot8Product> productList;
    Context context=this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot8_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listView =findViewById(R.id.slot8Listview);
        productList=new ArrayList<>();
        adapter = new Slot8Adapter(this,productList);
        listView.setAdapter(adapter);
        //Đọc dữ liệu từ server banh cách xử lý không đồng bộ với AsyncTask
        //AsyncTask<Đầu vào, Quá trình, Đầu ra>
        //ví dụ: AsyncTask<Void,Void,String>: chỉ quan tâm đến đầu ra
        //hoặc AsyncTask<String,Void,String>: quan tâm cả đầu vào, đầu ra
        new FetchProductTask().execute();//thuc thi lay du lieu tu server
        //ham execute thuc hien viec: doc du lieu tu server + tra ket qua cho Client
    }
    private class FetchProductTask extends AsyncTask<Void,Void,String>{
        //doc du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            StringBuilder response =new StringBuilder();//chua du lieu doc duoc
            try {
                //duong dan
                URL url = new URL("https://hungnttg.github.io/shopgiay.json");
                //mo ket noi den server
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");//xac dinh phuong thuc tra du lieu
                //dung bo dem de chua du lieu doc duoc
                BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                //Dung bo dem Doc theo tung dong
                String line;
                while ((line=reader.readLine())!=null){
                    response.append(line);//dua dong doc duoc vao ket qua
                }
                reader.close();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return response.toString();//tra ve ket qua
        }
        //tra ket qua ve client
        @Override
        protected void onPostExecute(String result) {
            if(result!=null && !result.isEmpty()){
                try {
                    //lay ve doi tuong product
                    JSONObject json = new JSONObject(result);
                    //chuyen sang dang mang
                    JSONArray productArray = json.getJSONArray("products");
                    //lay tung doi tuong trong mang
                    for(int i=0;i<productArray.length();i++){
                        //lay ve tung object
                        JSONObject productObject = productArray.getJSONObject(i);
                        //boc tach cac thanh phan trong object
                        String brand = productObject.getString("brands_filter_facet");
                        String price = productObject.getString("price");
                        String search_image=productObject.getString("search_image");
                        String styleid=productObject.getString("styleid");
                        String additionalInfo = productObject.getString("product_additional_info");
                        //tao doi tuong voi cac truong co san
                        Slot8Product p = new Slot8Product(styleid,brand,price,additionalInfo,search_image);
                        //them vao list
                        productList.add(p);
                    }
                    //cap nhat apdapter
                    adapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}