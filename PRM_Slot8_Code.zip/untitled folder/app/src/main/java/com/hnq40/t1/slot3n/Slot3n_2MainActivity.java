package com.hnq40.t1.slot3n;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

public class Slot3n_2MainActivity extends AppCompatActivity {
    //Khai bao listview
    ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot3n2_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa listview
        listView = findViewById(R.id.S3n_listview);
        getDataToListview();
    }

    private void getDataToListview() {
        //1. Tao mang nguon du lieu
        String[] arr = new String[]{
            "Lap trinh java",
            "Lap trinh javascript",
            "Science Computer Introduction",
            "Software design"
        };
        //2. Taoj adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(Slot3n_2MainActivity.this,
                android.R.layout.simple_list_item_1,arr);
        //3. Gan Adapter vao Listview
        listView.setAdapter(adapter);
    }
}