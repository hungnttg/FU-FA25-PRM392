package com.hnq40.t1.slot8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hnq40.t1.R;

import java.util.List;

public class Slot9CartAdapter extends ArrayAdapter<Slot8Product> {
    private Context mContext;
    public Slot9CartAdapter(@NonNull Context context, List<Slot8Product> products) {
        super(context,0, products);
        mContext = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null){
            listItem = LayoutInflater.from(mContext)
                    .inflate(R.layout.slot9_cart_item,parent,false);
        }
        //get current product
        Slot8Product currentProduct = getItem(position);
        //display info of product in cart
        TextView productName = listItem.findViewById(R.id.slot9CartItem_TxtName);
        //set data for productName
        productName.setText(currentProduct.getAdditionalInfo());
        //display quantity and price
        TextView productQuantity = listItem.findViewById(R.id.slot9CartItem_TxtQuantity);
        productQuantity.setText("Quantity: "+1);
        //xu ly su kien khi nguoi dung thay doi so luong o day
        return listItem;

    }
}
