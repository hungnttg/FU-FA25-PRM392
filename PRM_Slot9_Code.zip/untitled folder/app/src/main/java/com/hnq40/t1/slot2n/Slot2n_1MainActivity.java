package com.hnq40.t1.slot2n;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

public class Slot2n_1MainActivity extends AppCompatActivity {
    //declare some controls
    EditText txt1, txt2;
    Button btn1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot2n1_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //reference
        txt1 = findViewById(R.id.slot2n_1Txt1);
        txt2 = findViewById(R.id.slot2n_1Txt2);
        btn1 = findViewById(R.id.slot2n_1Btn1);
        //event
        btn1.setOnClickListener(v->{
            //lay gia tri nguoi dung nhap va convert sang so thuc
            float a = Float.parseFloat(txt1.getText().toString());
            float b = Float.parseFloat(txt2.getText().toString());
//            //tinh tong
//            float tong = a+b;
//            //hien thi cho nguoi dung
//            Toast.makeText(this, String.valueOf(tong), Toast.LENGTH_SHORT).show();
            //Tao intent van chuyen du lieu
            Intent intent = new Intent(Slot2n_1MainActivity.this,
                    Slot2n_2MainActivity.class);
            //dua du lieu vao intent
            intent.putExtra("so1",a);
            intent.putExtra("so2",b);
            //van chuyen du lieu
            startActivity(intent);
        });

    }
}