package com.hnq40.t1.slot3n;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hnq40.t1.R;

public class Slot3n_1MainActivity extends AppCompatActivity {
    //Khai bao cacs control
    EditText txt1,txt2;
    Button btn1;
    TextView tv1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot3n1_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa cac thanh phan
        txt1 = findViewById(R.id.S3n_1Txt1);
        txt2=findViewById(R.id.S3n_1Txt2);
        tv1=findViewById(R.id.S3n_1Tv1);
        btn1 = findViewById(R.id.S3n_1Btn1);
        //xu ly su kien
        btn1.setOnClickListener(v->{
            login();
        });

    }

    private void login() {
        //kiem tra nguoi dung nhap
        if(txt1.getText().toString().equals("admin") && txt2.getText().toString().equals("123456")){
            tv1.setText("Login successful");
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
        }
        else {
            tv1.setText("Sai user hoac pass");
            Toast.makeText(this, "Sai user hoac pass", Toast.LENGTH_SHORT).show();
        }
    }
}