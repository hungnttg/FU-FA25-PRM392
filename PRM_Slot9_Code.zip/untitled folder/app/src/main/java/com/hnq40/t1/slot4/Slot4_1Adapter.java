package com.hnq40.t1.slot4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.t1.R;

import java.util.List;

public class Slot4_1Adapter extends BaseAdapter {
    private Context context;
    private List<Slot4Student> list;

    public Slot4_1Adapter(Context context, List<Slot4Student> list) {
        this.context = context;
        this.list = list;
    }

    //tra ve tong cac item
    @Override
    public int getCount() {
        return list.size();
    }
    //tra ve 1 item
    @Override
    public Object getItem(int position) {
        return list.get(position);
    }
    //tra ve id cua item
    @Override
    public long getItemId(int position) {
        return position;
    }

    //tao blank view
    //dien du lieu cho view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. create view
        Slot4_1ViewHolder holder;
        if(convertView==null){//if exist view -> create a new view
            // tao 1 blank view gan voi layout da co
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.slot4_1_item_view,parent,false);
            //anh xa tung truong trong view holder
            holder = new Slot4_1ViewHolder();
            holder.imgHinh = convertView.findViewById(R.id.slot4_1_itemview_img);
            holder.tvTen=convertView.findViewById(R.id.slot4_1_itemview_tvTen);
            holder.tvTuoi=convertView.findViewById(R.id.slot4_1_itemview_tvTuoi);
            //create a template for later
            convertView.setTag(holder);
        }
        else {// exist iew -> get old view
            holder = (Slot4_1ViewHolder)convertView.getTag();//lay view cu
        }
        //2. truyen du lieu cho view
        Slot4Student student=list.get(position);//get a object
        holder.imgHinh.setImageResource(student.getHinh());
        holder.tvTen.setText(student.getTen());
        holder.tvTuoi.setText(student.getTuoi());
        return convertView;

    }
    //tao lop viewholer (code cua itemview)
    static class Slot4_1ViewHolder {
        ImageView imgHinh;
        TextView tvTen,tvTuoi;
    }
}
