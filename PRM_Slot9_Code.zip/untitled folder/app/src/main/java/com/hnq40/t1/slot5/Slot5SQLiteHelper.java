package com.hnq40.t1.slot5;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Slot5SQLiteHelper extends SQLiteOpenHelper {
    //lenh tao bang du lieu
    public static final String
            SQL_CREATE_PRODUCT="CREATE TABLE Product (id text PRIMARY KEY,name text,price real);";
    public Slot5SQLiteHelper(Context context) {
        super(context, "PRM", null, 1);//tao db
    }

    //tao bang du lieu
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_PRODUCT);
    }
    //update bang du lieu
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Product");
    }
}
