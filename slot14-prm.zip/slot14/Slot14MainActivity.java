package com.hnq40.t1.slot14;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hnq40.t1.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Slot14MainActivity extends AppCompatActivity {
    Button btnGet;
    TextView tvResult;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot14_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnGet = findViewById(R.id.slot14Btn);
        tvResult = findViewById(R.id.slot14Tv);
        btnGet.setOnClickListener(v->{
            getStringVolley(context,tvResult);
        });
    }
    String str="";
    private void getJSON_Array_of_object(Context context, TextView tvResult) {
        str="";
        //1. Tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2.url
        String url="https://hungnttg.github.io/array_json_new.json";
        //3. goi request
        //Mang cua cac doi tuong => goi mang truoc, doi tuong sau
        //JsonArrayRequest(url,thanhcong,thatbai)
        JsonArrayRequest request = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //chuyen ket qua: mang => doi tuong
                for(int i=0;i<response.length();i++){
                    try {
                        //lay ve doi tuong
                        JSONObject person=response.getJSONObject(i);
                        //lay ve tung truong du lieu
                        String name = person.getString("name");
                        String email=person.getString("email");
                        JSONObject phone=person.getJSONObject("phone");
                        String mobile = phone.getString("mobile");
                        String home = phone.getString("home");
                        //chuyen thanh chuoi
                        str+="Name: "+name+"\n";
                        str+="Email: "+email+"\n";
                        str+="Mobile: "+mobile+"\n";
                        str+="Home: "+home+"\n";

                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                    tvResult.setText(str);//tra ve client
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvResult.setText(error.getMessage());
            }
        });
        //4. thuc thi request
        queue.add(request);
    }
    //=====
    public void getStringVolley(Context context,TextView tvResult){
        //1. Tao request
        RequestQueue queue=Volley.newRequestQueue(context);
        //2. url
        String url="https://www.google.com/";
        //3, truyen tham so
        //StringRequest(phuongThuc,url,thanhCong,thatBai)
        StringRequest stringRequest=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        tvResult.setText("Ket qua: "+response.substring(0,1000));
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvResult.setText(error.getMessage());
            }
        });
        //4. thuc thi request
        queue.add(stringRequest);
    }
}